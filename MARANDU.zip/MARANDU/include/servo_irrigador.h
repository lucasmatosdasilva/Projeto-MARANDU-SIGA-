#ifndef SERVO_IRRIGADOR_H
#define SERVO_IRRIGADOR_H

#include <stdbool.h>

void servo_irrigador_init(void);
void servo_irrigador_atualizar(bool irrigador_ligado);

#endif