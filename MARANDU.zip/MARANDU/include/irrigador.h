#ifndef IRRIGADOR_H
#define IRRIGADOR_H

#include <stdbool.h>

typedef enum {
    IRRIGADOR_NORMAL = 0,
    IRRIGADOR_ATENCAO,
    IRRIGADOR_IRRIGAR,
    IRRIGADOR_CRITICO
} estado_irrigador_t;

typedef struct {
    estado_irrigador_t estado;
    bool irrigador_ligado;
    const char *mensagem;
} decisao_irrigador_t;

void irrigador_init(void);

decisao_irrigador_t irrigador_avaliar(
    float temperatura,
    float umidade,
    float pressao,
    bool leitura_aht10_ok
);

#endif