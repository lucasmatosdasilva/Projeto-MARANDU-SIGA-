#ifndef WIFI_AP_H
#define WIFI_AP_H

#include <stdbool.h>

typedef struct {
    float temperatura_media;
    float temperatura_aht10;
    float temperatura_bmp280;
    float umidade;
    float pressao;
    bool aht10_ok;

    const char *status_irrigador;
    bool irrigador_ligado;
} dados_ambiente_t;

bool wifi_ap_init(void);
void wifi_ap_atualizar_dados(dados_ambiente_t dados);

// Novas funções para controle manual pela página web
bool wifi_ap_modo_manual_ativo(void);
bool wifi_ap_irrigador_manual_ligado(void);

#endif