#ifndef DISPLAY_OLED_H
#define DISPLAY_OLED_H

#include <stdbool.h>

bool display_oled_init(void);

void display_oled_atualizar(
    float temperatura_media,
    float umidade,
    float pressao,
    bool aht10_ok
);

#endif