#include "irrigador.h"

// Limiares principais
#define TEMP_LIGAR_IRRIGADOR       30.0f
#define TEMP_DESLIGAR_IRRIGADOR    29.9f

#define UMIDADE_LIGAR_IRRIGADOR    90.5f
#define UMIDADE_DESLIGAR_IRRIGADOR 91.5f

#define TEMP_CRITICA               32.0f
#define UMIDADE_CRITICA            88.0f

static bool irrigador_ligado = false;

void irrigador_init(void) {
    irrigador_ligado = false;
}

decisao_irrigador_t irrigador_avaliar(
    float temperatura,
    float umidade,
    float pressao,
    bool leitura_aht10_ok
) {
    decisao_irrigador_t decisao;

    // Se o AHT10 falhar, não confia na umidade do ar
    if (!leitura_aht10_ok) {
        irrigador_ligado = false;

        decisao.estado = IRRIGADOR_NORMAL;
        decisao.irrigador_ligado = false;
        decisao.mensagem = "SENSOR ERRO";

        return decisao;
    }

    // Estado crítico
    if (temperatura >= TEMP_CRITICA && umidade <= UMIDADE_CRITICA) {
        irrigador_ligado = true;

        decisao.estado = IRRIGADOR_CRITICO;
        decisao.irrigador_ligado = true;
        decisao.mensagem = "CRITICO";

        return decisao;
    }

    // Liga com histerese
    if (!irrigador_ligado) {
        if (temperatura >= TEMP_LIGAR_IRRIGADOR && umidade <= UMIDADE_LIGAR_IRRIGADOR) {
            irrigador_ligado = true;
        }
    } else {
        if (temperatura <= TEMP_DESLIGAR_IRRIGADOR || umidade >= UMIDADE_DESLIGAR_IRRIGADOR) {
            irrigador_ligado = false;
        }
    }

    // Define o estado textual
    if (irrigador_ligado) {
        decisao.estado = IRRIGADOR_IRRIGAR;
        decisao.irrigador_ligado = true;
        decisao.mensagem = "IRRIGAR";
    } else if (temperatura >= TEMP_LIGAR_IRRIGADOR || umidade <= UMIDADE_LIGAR_IRRIGADOR) {
        decisao.estado = IRRIGADOR_ATENCAO;
        decisao.irrigador_ligado = false;
        decisao.mensagem = "ATENCAO";
    } else {
        decisao.estado = IRRIGADOR_NORMAL;
        decisao.irrigador_ligado = false;
        decisao.mensagem = "NORMAL";
    }

    return decisao;
}