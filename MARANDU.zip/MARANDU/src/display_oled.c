#include <stdio.h>
#include <string.h>
#include <stdbool.h>

#include "pico/stdlib.h"
#include "hardware/i2c.h"

#include "ssd1306.h"
#include "display_oled.h"

// OLED da BitDogLab
#define OLED_I2C_PORT i2c1
#define OLED_SDA_PIN 14
#define OLED_SCL_PIN 15

#define OLED_WIDTH 128
#define OLED_HEIGHT 64

static ssd1306_t oled;

static int arredondar_float(float valor) {
    if (valor >= 0.0f) {
        return (int)(valor + 0.5f);
    } else {
        return (int)(valor - 0.5f);
    }
}

static bool oled_verificar_conexao(void) {
    uint8_t dado = 0x00;

    int ret = i2c_write_blocking(
        OLED_I2C_PORT,
        ssd1306_i2c_address,
        &dado,
        1,
        false
    );

    return ret >= 0;
}

static void display_oled_limpar(void) {
    if (oled.ram_buffer != NULL) {
        memset(oled.ram_buffer + 1, 0, oled.bufsize - 1);
    }
}

static void display_oled_enviar(void) {
    ssd1306_command(&oled, ssd1306_set_column_address);
    ssd1306_command(&oled, 0);
    ssd1306_command(&oled, OLED_WIDTH - 1);

    ssd1306_command(&oled, ssd1306_set_page_address);
    ssd1306_command(&oled, 0);
    ssd1306_command(&oled, (OLED_HEIGHT / 8) - 1);

    ssd1306_send_data(&oled);
}

bool display_oled_init(void) {
    i2c_init(OLED_I2C_PORT, 400 * 1000);

    gpio_set_function(OLED_SDA_PIN, GPIO_FUNC_I2C);
    gpio_set_function(OLED_SCL_PIN, GPIO_FUNC_I2C);

    gpio_pull_up(OLED_SDA_PIN);
    gpio_pull_up(OLED_SCL_PIN);

    sleep_ms(100);

    printf("[OLED] Testando endereco 0x%02X...\n", ssd1306_i2c_address);

    if (!oled_verificar_conexao()) {
        printf("[OLED] ERRO: Display nao respondeu no I2C.\n");
        return false;
    }

    printf("[OLED] Display encontrado no endereco 0x%02X.\n", ssd1306_i2c_address);

    ssd1306_init_bm(
        &oled,
        OLED_WIDTH,
        OLED_HEIGHT,
        false,
        ssd1306_i2c_address,
        OLED_I2C_PORT
    );

    ssd1306_config(&oled);

    // No seu codigo-base essa funcao tambem era chamada.
    ssd1306_init();

    display_oled_limpar();

    ssd1306_draw_string(oled.ram_buffer + 1, 32, 0,  "MARANDU");
    ssd1306_draw_string(oled.ram_buffer + 1, 16, 16, "INICIANDO");
    ssd1306_draw_string(oled.ram_buffer + 1, 32, 32, "SENSORES");
    ssd1306_draw_string(oled.ram_buffer + 1, 24, 48, "AGUARDE");

    display_oled_enviar();

    return true;
}

void display_oled_atualizar(
    float temperatura_media,
    float umidade,
    float pressao,
    bool aht10_ok
) {
    char linha_temp[20];
    char linha_umid[20];
    char linha_pres[20];

    int temp_int = arredondar_float(temperatura_media);
    int umid_int = arredondar_float(umidade);
    int pres_int = arredondar_float(pressao);

    snprintf(linha_temp, sizeof(linha_temp), "TEMP %dC", temp_int);

    if (aht10_ok) {
        snprintf(linha_umid, sizeof(linha_umid), "UMID %d", umid_int);
    } else {
        snprintf(linha_umid, sizeof(linha_umid), "UMID ERRO");
    }

    snprintf(linha_pres, sizeof(linha_pres), "PRES %d", pres_int);

    display_oled_limpar();

    ssd1306_draw_string(oled.ram_buffer + 1, 32, 0,  "MARANDU");
    ssd1306_draw_string(oled.ram_buffer + 1, 0,  16, linha_temp);
    ssd1306_draw_string(oled.ram_buffer + 1, 0,  32, linha_umid);
    ssd1306_draw_string(oled.ram_buffer + 1, 0,  48, linha_pres);

    display_oled_enviar();
}