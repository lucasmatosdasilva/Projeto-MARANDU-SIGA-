#include <stdio.h>
#include <string.h>
#include <stdbool.h>

#include "pico/stdlib.h"
#include "pico/cyw43_arch.h"

#include "lwip/pbuf.h"
#include "lwip/tcp.h"
#include "lwip/ip4_addr.h"

#include "dhcpserver.h"
#include "dnsserver.h"

#include "wifi_ap.h"

#define TCP_PORT 80

#define WIFI_AP_SSID "MARANDU"
#define WIFI_AP_PASSWORD "12345678"

#define HTTP_GET "GET"

#define HTTP_RESPONSE_HEADERS \
    "HTTP/1.1 200 OK\r\n" \
    "Content-Type: text/html; charset=utf-8\r\n" \
    "Connection: close\r\n" \
    "\r\n"

static dados_ambiente_t dados_atuais;

static dhcp_server_t dhcp_server;
static dns_server_t dns_server;

static bool modo_manual = false;
static bool irrigador_manual_ligado = false;

static const char *status_seguro(void) {
    if (modo_manual) {
        return irrigador_manual_ligado ? "IRRIGAR" : "NORMAL";
    }

    if (dados_atuais.status_irrigador == NULL) {
        return "NORMAL";
    }

    return dados_atuais.status_irrigador;
}

static const char *cor_status(const char *status) {
    if (strcmp(status, "CRITICO") == 0) {
        return "#c62828";
    }

    if (strcmp(status, "IRRIGAR") == 0) {
        return "#1565c0";
    }

    if (strcmp(status, "ATENCAO") == 0) {
        return "#f57c00";
    }

    return "#2e7d32";
}

static const char *fundo_status(const char *status) {
    if (strcmp(status, "CRITICO") == 0) {
        return "#ffebee";
    }

    if (strcmp(status, "IRRIGAR") == 0) {
        return "#e3f2fd";
    }

    if (strcmp(status, "ATENCAO") == 0) {
        return "#fff8e1";
    }

    return "#e8f5e9";
}

static void processar_comando_web(const char *request) {
    if (strstr(request, "GET /?irrigador=ligar") != NULL) {
        modo_manual = true;
        irrigador_manual_ligado = true;
        printf("[WEB] Manual: irrigador LIGADO\n");
    }
    else if (strstr(request, "GET /?irrigador=desligar") != NULL) {
        modo_manual = true;
        irrigador_manual_ligado = false;
        printf("[WEB] Manual: irrigador DESLIGADO\n");
    }
    else if (strstr(request, "GET /?irrigador=auto") != NULL) {
        modo_manual = false;
        irrigador_manual_ligado = false;
        printf("[WEB] Modo automatico\n");
    }
}

static int gerar_pagina_html(char *html, size_t max_len) {
    const char *status = status_seguro();
    const char *status_cor = cor_status(status);
    const char *status_bg = fundo_status(status);

    bool irrigador_final = modo_manual ? irrigador_manual_ligado : dados_atuais.irrigador_ligado;

    const char *irrigador_txt = irrigador_final ? "LIGADO" : "DESLIGADO";
    const char *irrigador_cor = irrigador_final ? "#1b7f3a" : "#4b5563";
    const char *irrigador_bg = irrigador_final ? "#e8f5e9" : "#f3f4f6";

    const char *modo_txt = modo_manual ? "MANUAL" : "AUTOMATICO";
    const char *modo_cor = modo_manual ? "#5e35b1" : "#00695c";
    const char *modo_bg = modo_manual ? "#ede7f6" : "#e0f2f1";

    const char *sensor_txt = dados_atuais.aht10_ok ? "OK" : "FALHA";

    return snprintf(html, max_len,
        "<!DOCTYPE html>"
        "<html><head>"
        "<meta charset='UTF-8'>"
        "<meta name='viewport' content='width=device-width,initial-scale=1'>"
        "<meta http-equiv='refresh' content='2'>"
        "<title>MARANDU</title>"
        "<style>"
        "body{margin:0;font-family:Arial;background:#eef5f0;color:#1f2937}"
        ".box{max-width:620px;margin:auto;background:white;min-height:100vh;padding:18px}"
        "h1{text-align:center;color:#1b4332;font-size:38px;margin:10px 0 5px}"
        "p{text-align:center;color:#6b7280;margin:0 0 18px}"
        ".tag{text-align:center;background:#d8f3dc;color:#1b4332;padding:7px;border-radius:20px;font-weight:bold;font-size:12px}"
        ".grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}"
        ".card{background:#f8faf9;border:1px solid #e5e7eb;border-radius:16px;padding:14px;text-align:center}"
        ".full{grid-column:1/3}"
        ".lab{font-size:12px;color:#6b7280;font-weight:bold;text-transform:uppercase}"
        ".val{font-size:30px;color:#2d6a4f;font-weight:900;margin-top:5px}"
        ".state{border-radius:16px;padding:15px;text-align:center;margin-top:10px;font-weight:900}"
        ".state .lab{color:inherit}"
        ".state .val{color:inherit;font-size:31px}"
        ".btn{display:block;text-align:center;text-decoration:none;margin-top:10px;padding:14px;border-radius:14px;font-weight:900}"
        ".on{background:#e8f5e9;color:#1b7f3a}"
        ".off{background:#ffebee;color:#c62828}"
        ".auto{background:#e3f2fd;color:#1565c0}"
        ".foot{text-align:center;color:#6b7280;font-size:12px;margin-top:14px;border-top:1px solid #ddd;padding-top:10px}"
        "@media(max-width:520px){.grid{grid-template-columns:1fr}.full{grid-column:1}.box{padding:16px}h1{font-size:36px}.val{font-size:34px}}"
        "</style>"
        "</head><body>"
        "<div class='box'>"

        "<div class='tag'>AGRICULTURA FAMILIAR</div>"
        "<h1>Projeto<br>MARANDU</h1>"
        "<p>Monitoramento ambiental e irrigacao inteligente</p>"

        "<div class='grid'>"
        "<div class='card full'><div class='lab'>Temperatura media</div><div class='val'>%.2f &deg;C</div></div>"
        "<div class='card'><div class='lab'>Umidade</div><div class='val'>%.2f %%</div></div>"
        "<div class='card'><div class='lab'>Pressao</div><div class='val'>%.1f hPa</div></div>"
        "<div class='card full'><div class='lab'>Sensor AHT10</div><div class='val'>%s</div></div>"
        "</div>"

        "<div class='state' style='background:%s;color:%s'>"
        "<div class='lab'>Status da condicao</div><div class='val'>%s</div>"
        "</div>"

        "<div class='state' style='background:%s;color:%s'>"
        "<div class='lab'>Servo / Irrigador</div><div class='val'>%s</div>"
        "</div>"

        "<div class='state' style='background:%s;color:%s'>"
        "<div class='lab'>Modo de controle</div><div class='val'>%s</div>"
        "</div>"

        "<a class='btn on' href='/?irrigador=ligar'>LIGAR IRRIGADOR</a>"
        "<a class='btn off' href='/?irrigador=desligar'>DESLIGAR IRRIGADOR</a>"
        "<a class='btn auto' href='/?irrigador=auto'>VOLTAR PARA AUTOMATICO</a>"

        "<div class='foot'>Atualizacao a cada 2 segundos<br>Wi-Fi: MARANDU | IP: 192.168.4.1</div>"

        "</div></body></html>",

        dados_atuais.temperatura_media,
        dados_atuais.umidade,
        dados_atuais.pressao,
        sensor_txt,

        status_bg,
        status_cor,
        status,

        irrigador_bg,
        irrigador_cor,
        irrigador_txt,

        modo_bg,
        modo_cor,
        modo_txt
    );
}

static err_t tcp_server_recv(void *arg, struct tcp_pcb *pcb, struct pbuf *p, err_t err) {
    if (!p) {
        tcp_close(pcb);
        return ERR_OK;
    }

    char request[512] = {0};
    static char response[4096];

    memset(response, 0, sizeof(response));

    pbuf_copy_partial(
        p,
        request,
        p->tot_len < sizeof(request) ? p->tot_len : sizeof(request) - 1,
        0
    );

    processar_comando_web(request);

    if (strncmp(request, HTTP_GET, strlen(HTTP_GET)) == 0) {
        int html_len = gerar_pagina_html(response, sizeof(response));

        if (html_len < 0) {
            html_len = 0;
        }

        if (html_len >= sizeof(response)) {
            html_len = sizeof(response) - 1;
        }

        tcp_write(pcb, HTTP_RESPONSE_HEADERS, strlen(HTTP_RESPONSE_HEADERS), TCP_WRITE_FLAG_COPY);
        tcp_write(pcb, response, html_len, TCP_WRITE_FLAG_COPY);
        tcp_output(pcb);
    }

    tcp_recved(pcb, p->tot_len);
    pbuf_free(p);

    return ERR_OK;
}

static err_t tcp_server_accept(void *arg, struct tcp_pcb *new_pcb, err_t err) {
    tcp_recv(new_pcb, tcp_server_recv);
    return ERR_OK;
}

bool wifi_ap_init(void) {
    if (cyw43_arch_init()) {
        printf("[WIFI] Erro ao inicializar CYW43.\n");
        return false;
    }

    cyw43_arch_enable_ap_mode(
        WIFI_AP_SSID,
        WIFI_AP_PASSWORD,
        CYW43_AUTH_WPA2_AES_PSK
    );

    ip4_addr_t ip;
    ip4_addr_t mask;

    IP4_ADDR(&ip, 192, 168, 4, 1);
    IP4_ADDR(&mask, 255, 255, 255, 0);

    dhcp_server_init(&dhcp_server, &ip, &mask);
    dns_server_init(&dns_server, &ip);

    struct tcp_pcb *pcb = tcp_new_ip_type(IPADDR_TYPE_ANY);

    if (!pcb) {
        printf("[HTTP] Erro ao criar PCB TCP.\n");
        return false;
    }

    if (tcp_bind(pcb, IP_ANY_TYPE, TCP_PORT) != ERR_OK) {
        printf("[HTTP] Erro ao vincular servidor na porta %d.\n", TCP_PORT);
        return false;
    }

    pcb = tcp_listen_with_backlog(pcb, 1);
    tcp_accept(pcb, tcp_server_accept);

    printf("[WIFI] Access Point ativo.\n");
    printf("[WIFI] Nome da rede: %s\n", WIFI_AP_SSID);
    printf("[WIFI] Senha: %s\n", WIFI_AP_PASSWORD);
    printf("[HTTP] Acesse: http://192.168.4.1\n");

    return true;
}

void wifi_ap_atualizar_dados(dados_ambiente_t dados) {
    dados_atuais = dados;
}

bool wifi_ap_modo_manual_ativo(void) {
    return modo_manual;
}

bool wifi_ap_irrigador_manual_ligado(void) {
    return irrigador_manual_ligado;
}