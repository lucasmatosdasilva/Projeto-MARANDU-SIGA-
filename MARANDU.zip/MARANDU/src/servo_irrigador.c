#include "servo_irrigador.h"

#include "pico/stdlib.h"
#include "hardware/pwm.h"

// Pino usado para o sinal PWM do servo
#define SERVO_PIN 16

// PWM para servo: 50 Hz
#define SERVO_WRAP 20000

// Pulsos em microssegundos
#define SERVO_POSICAO_ESQUERDA_US 1000
#define SERVO_POSICAO_CENTRO_US   1500
#define SERVO_POSICAO_DIREITA_US  2000

static uint slice_num;
static uint channel;

// Variável para alternar o movimento
static bool servo_para_direita = true;

static void servo_set_pulso_us(uint16_t pulso_us) {
    pwm_set_chan_level(slice_num, channel, pulso_us);
}

void servo_irrigador_init(void) {
    gpio_set_function(SERVO_PIN, GPIO_FUNC_PWM);

    slice_num = pwm_gpio_to_slice_num(SERVO_PIN);
    channel = pwm_gpio_to_channel(SERVO_PIN);

    /*
     * Clock padrão do PWM: 125 MHz
     * Dividindo por 125, fica 1 MHz
     * Assim, 1 contagem = 1 microssegundo
     */
    pwm_set_clkdiv(slice_num, 125.0f);

    /*
     * 20.000 us = 20 ms
     * Frequência = 50 Hz
     */
    pwm_set_wrap(slice_num, SERVO_WRAP);

    // Começa parado no centro
    servo_set_pulso_us(SERVO_POSICAO_CENTRO_US);

    pwm_set_enabled(slice_num, true);
}

void servo_irrigador_atualizar(bool irrigador_ligado) {
    if (irrigador_ligado) {
        if (servo_para_direita) {
            servo_set_pulso_us(SERVO_POSICAO_DIREITA_US);
        } else {
            servo_set_pulso_us(SERVO_POSICAO_ESQUERDA_US);
        }

        servo_para_direita = !servo_para_direita;
    } else {
        // Quando não estiver irrigando, volta para o centro
        servo_set_pulso_us(SERVO_POSICAO_CENTRO_US);
        servo_para_direita = true;
    }
}