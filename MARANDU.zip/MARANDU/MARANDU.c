#include <stdio.h>
#include <stdbool.h>

#include "pico/stdlib.h"
#include "pico/mutex.h"
#include "hardware/i2c.h"

#include "aht10.h"
#include "bmp280.h"
#include "wifi_ap.h"
#include "display_oled.h"
#include "irrigador.h"
#include "servo_irrigador.h"

// Sensores AHT10 e BMP280 no mesmo barramento I2C0
#define SENSORES_I2C_PORT i2c0
#define SENSORES_SDA_PIN 0
#define SENSORES_SCL_PIN 1

// Mutex para proteger o barramento I2C0
static mutex_t i2c0_mutex;

static void configurar_i2c_sensores(void) {
    // Usa 100 kHz para garantir compatibilidade com o AHT10 e BMP280
    i2c_init(SENSORES_I2C_PORT, 100 * 1000);

    gpio_set_function(SENSORES_SDA_PIN, GPIO_FUNC_I2C);
    gpio_set_function(SENSORES_SCL_PIN, GPIO_FUNC_I2C);

    gpio_pull_up(SENSORES_SDA_PIN);
    gpio_pull_up(SENSORES_SCL_PIN);
}

static bool inicializar_aht10_com_mutex(void) {
    bool resultado;

    mutex_enter_blocking(&i2c0_mutex);
    resultado = aht10_init(SENSORES_I2C_PORT);
    mutex_exit(&i2c0_mutex);

    return resultado;
}

static void inicializar_bmp280_com_mutex(bmp280_calib_params_t *params) {
    mutex_enter_blocking(&i2c0_mutex);

    bmp280_init(SENSORES_I2C_PORT);
    bmp280_get_calib_params(SENSORES_I2C_PORT, params);

    mutex_exit(&i2c0_mutex);
}

static bool ler_aht10_com_mutex(aht10_data_t *dados_aht10) {
    bool resultado;

    mutex_enter_blocking(&i2c0_mutex);
    resultado = aht10_read_data(SENSORES_I2C_PORT, dados_aht10);
    mutex_exit(&i2c0_mutex);

    return resultado;
}

static void ler_bmp280_com_mutex(
    int32_t *raw_temp_bmp,
    int32_t *raw_pressure
) {
    mutex_enter_blocking(&i2c0_mutex);

    bmp280_read_raw(SENSORES_I2C_PORT, raw_temp_bmp, raw_pressure);

    mutex_exit(&i2c0_mutex);
}

int main() {
    stdio_init_all();

    while (!stdio_usb_connected()) {
        sleep_ms(100);
    }

    printf("\n--- Projeto MARANDU ---\n");
    printf("Iniciando sensores AHT10 e BMP280 no mesmo I2C...\n\n");

    printf("AHT10  -> I2C0 | SDA GPIO%d | SCL GPIO%d\n", SENSORES_SDA_PIN, SENSORES_SCL_PIN);
    printf("BMP280 -> I2C0 | SDA GPIO%d | SCL GPIO%d\n", SENSORES_SDA_PIN, SENSORES_SCL_PIN);
    printf("OLED   -> I2C1 | SDA GPIO14 | SCL GPIO15\n");
    printf("SERVO  -> PWM  | GPIO16\n\n");

    // Inicializa mutex
    mutex_init(&i2c0_mutex);

    // Inicializa barramento dos sensores
    configurar_i2c_sensores();

    // Inicializa AHT10
    if (!inicializar_aht10_com_mutex()) {
        printf("ERRO: Falha ao inicializar o sensor AHT10.\n");

        while (true) {
            sleep_ms(1000);
        }
    }

    printf("AHT10 inicializado com sucesso.\n");

    // Inicializa BMP280
    bmp280_calib_params_t bmp_params;
    inicializar_bmp280_com_mutex(&bmp_params);

    printf("BMP280 inicializado com sucesso.\n\n");

    // Inicializa display OLED
    printf("Iniciando display OLED...\n");

    if (!display_oled_init()) {
        printf("ERRO: Falha ao inicializar o display OLED.\n");
    } else {
        printf("Display OLED inicializado com sucesso.\n\n");
    }

    // Inicializa Wi-Fi AP
    printf("Iniciando Wi-Fi em modo Access Point...\n");

    if (!wifi_ap_init()) {
        printf("ERRO: Falha ao iniciar Wi-Fi AP.\n");

        while (true) {
            sleep_ms(1000);
        }
    }

    // Inicializa lógica do irrigador
    irrigador_init();
    printf("Logica do irrigador inicializada.\n");

    // Inicializa servo motor da irrigação
    servo_irrigador_init();
    printf("Servo do irrigador inicializado.\n");

    printf("\nColetando dados...\n\n");

    while (true) {
        aht10_data_t dados_aht10;

        int32_t raw_temp_bmp;
        int32_t raw_pressure;
        int32_t temp_bmp_celsius;
        int32_t pressure_pa_fixed;

        float temperatura_aht10 = 0.0f;
        float umidade_aht10 = 0.0f;
        float temperatura_bmp280 = 0.0f;
        float pressao_hpa = 0.0f;
        float temperatura_media = 0.0f;

        // Lê AHT10 protegido pelo mutex
        bool leitura_aht10_ok = ler_aht10_com_mutex(&dados_aht10);

        // Lê BMP280 protegido pelo mutex
        ler_bmp280_com_mutex(&raw_temp_bmp, &raw_pressure);

        // Conversões do BMP280
        temp_bmp_celsius = bmp280_convert_temp(raw_temp_bmp, &bmp_params);
        pressure_pa_fixed = bmp280_convert_pressure(raw_pressure, &bmp_params);

        temperatura_bmp280 = temp_bmp_celsius / 100.0f;
        pressao_hpa = pressure_pa_fixed / 25600.0f;

        if (leitura_aht10_ok) {
            temperatura_aht10 = dados_aht10.temperature;
            umidade_aht10 = dados_aht10.humidity;

            // Temperatura final como média entre AHT10 e BMP280
            temperatura_media = (temperatura_aht10 + temperatura_bmp280) / 2.0f;
        } else {
            // Se o AHT10 falhar, usa somente a temperatura do BMP280
            temperatura_media = temperatura_bmp280;
        }

        // Avalia se deve irrigar ou não
        decisao_irrigador_t decisao = irrigador_avaliar(
            temperatura_media,
            umidade_aht10,
            pressao_hpa,
            leitura_aht10_ok
        );

        if (wifi_ap_modo_manual_ativo()) {
            if (wifi_ap_irrigador_manual_ligado()) {
                decisao.estado = IRRIGADOR_IRRIGAR;
                decisao.irrigador_ligado = true;
                decisao.mensagem = "IRRIGAR";
        } else {
            decisao.estado = IRRIGADOR_NORMAL;
            decisao.irrigador_ligado = false;
            decisao.mensagem = "NORMAL";
        }
    }

        // Atualiza o servo conforme a decisão do irrigador
        servo_irrigador_atualizar(decisao.irrigador_ligado);

        dados_ambiente_t dados_web = {
        .temperatura_media = temperatura_media,
        .temperatura_aht10 = temperatura_aht10,
        .temperatura_bmp280 = temperatura_bmp280,
        .umidade = umidade_aht10,
        .pressao = pressao_hpa,
        .aht10_ok = leitura_aht10_ok,

        .status_irrigador = decisao.mensagem,
        .irrigador_ligado = decisao.irrigador_ligado
        };

        // Atualiza os dados exibidos no servidor web
        wifi_ap_atualizar_dados(dados_web);

        // Atualiza o display OLED
        display_oled_atualizar(
            temperatura_media,
            umidade_aht10,
            pressao_hpa,
            leitura_aht10_ok
        );

        printf("====================================\n");

        if (leitura_aht10_ok) {
            printf("AHT10  - Temperatura: %.2f C\n", temperatura_aht10);
            printf("AHT10  - Umidade: %.2f %%\n", umidade_aht10);
        } else {
            printf("AHT10  - Falha na leitura.\n");
        }

        printf("BMP280 - Temperatura: %.2f C\n", temperatura_bmp280);
        printf("BMP280 - Pressao: %.2f hPa\n", pressao_hpa);

        printf("------------------------------------\n");
        printf("DADOS FINAIS DO AMBIENTE\n");
        printf("Temperatura media: %.2f C\n", temperatura_media);

        if (leitura_aht10_ok) {
            printf("Umidade: %.2f %%\n", umidade_aht10);
        } else {
            printf("Umidade: indisponivel\n");
        }

        printf("Pressao: %.2f hPa\n", pressao_hpa);

        printf("------------------------------------\n");
        printf("STATUS DO IRRIGADOR\n");
        printf("Condicao: %s\n", decisao.mensagem);

        if (decisao.irrigador_ligado) {
            printf("Acao: LIGAR IRRIGACAO\n");
            printf("Servo: GIRANDO\n");
        } else {
            printf("Acao: MANTER DESLIGADO\n");
            printf("Servo: PARADO\n");
        }

        printf("====================================\n\n");

        sleep_ms(2000);
    }

    return 0;
}